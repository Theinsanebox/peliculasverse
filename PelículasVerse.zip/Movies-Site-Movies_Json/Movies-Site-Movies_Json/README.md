# Movies-Site

an implementation of MCkenzie Child's tutorial https://www.youtube.com/watch?v=Dsyau8u1qvM&list=PL23ZvcdS3XPJZDL1M-kxoPF06cl9hfVB_&index=4

in the "movies-json" there's a few changes to the original project:

1-I implemented an ajax function to fetch movies data from an API.

2- Used bootstrap's Grid also Flexbox in the markup and styling..

more soon...
